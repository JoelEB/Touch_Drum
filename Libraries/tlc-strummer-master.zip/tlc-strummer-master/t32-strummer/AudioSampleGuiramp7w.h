// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleGuiramp7w[2273];
