// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleQuijadamp7w[9025];
