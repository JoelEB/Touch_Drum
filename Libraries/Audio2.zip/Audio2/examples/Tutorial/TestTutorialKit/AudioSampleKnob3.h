// Audio data converted from WAV file by wav2sketch

extern const unsigned int AudioSampleKnob3[3889];
